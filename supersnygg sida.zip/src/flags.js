export default [
  {
    emoji: "🇦🇩",
    name: "Andorra"
  },
  {
    emoji: "🇦🇪",
    name: "United Arab Emirates"
  },
  {
    emoji: "🇦🇫",
    name: "Afghanistan"
  },
  {
    emoji: "🇦🇮",
    name: "Anguilla"
  },
  {
    emoji: "🇦🇱",
    name: "Albania"
  },
  {
    emoji: "🇦🇲",
    name: "Armenia"
  },
  {
    emoji: "🇦🇴",
    name: "Angola"
  },
  {
    emoji: "🇦🇶",
    name: "Antarctica"
  },
  {
    emoji: "🇦🇷",
    name: "Argentina"
  },
  {
    emoji: "🇦🇹",
    name: "Austria"
  },
  {
    emoji: "🇦🇺",
    name: "Australia"
  },
  {
    emoji: "🇦🇿",
    name: "Azerbaijan"
  },
  {
    emoji: "🇧🇧",
    name: "Barbados"
  },
  {
    emoji: "🇧🇩",
    name: "Bangladesh"
  },
  {
    emoji: "🇧🇪",
    name: "Belgium"
  },
  {
    emoji: "🇧🇬",
    name: "Bulgaria"
  },
  {
    emoji: "🇧🇲",
    name: "Bermuda"
  },
  {
    emoji: "🇧🇴",
    name: "Bolivia"
  },
  {
    emoji: "🇧🇷",
    name: "Brazil"
  },
  {
    emoji: "🇧🇸",
    name: "Bahamas"
  },
  {
    emoji: "🇧🇹",
    name: "Bhutan"
  },
  {
    emoji: "🇧🇼",
    name: "Botswana"
  },
  {
    emoji: "🇧🇾",
    name: "Belarus"
  },
  {
    emoji: "🇧🇿",
    name: "Belize"
  },
  {
    emoji: "🇨🇦",
    name: "Canada"
  },
  {
    emoji: "🇨🇩",
    name: "Congo"
  },
  {
    emoji: "🇨🇬",
    name: "Congo"
  },
  {
    emoji: "🇨🇭",
    name: "Switzerland"
  },
  {
    emoji: "🇨🇱",
    name: "Chile"
  },
  {
    emoji: "🇨🇲",
    name: "Cameroon"
  },
  {
    emoji: "🇨🇳",
    name: "China"
  },
  {
    emoji: "🇨🇴",
    name: "Colombia"
  },
  {
    emoji: "🇨🇷",
    name: "Costa Rica"
  },
  {
    emoji: "🇨🇺",
    name: "Cuba"
  },
  {
    emoji: "🇨🇾",
    name: "Cyprus"
  },
  {
    emoji: "🇨🇿",
    name: "Czech Republic"
  },
  {
    emoji: "🇩🇪",
    name: "Germany"
  },
  {
    emoji: "🇩🇯",
    name: "Djibouti"
  },
  {
    emoji: "🇩🇰",
    name: "Denmark"
  },
  {
    emoji: "🇩🇴",
    name: "Dominican Republic"
  },
  {
    emoji: "🇩🇿",
    name: "Algeria"
  },
  {
    emoji: "🇪🇨",
    name: "Ecuador"
  },
  {
    emoji: "🇪🇪",
    name: "Estonia"
  },
  {
    emoji: "🇪🇬",
    name: "Egypt"
  },
  {
    emoji: "🇪🇸",
    name: "Spain"
  },
  {
    emoji: "🇪🇹",
    name: "Ethiopia"
  },
  {
    emoji: "🇫🇮",
    name: "Finland"
  },
  {
    emoji: "🇫🇯",
    name: "Fiji"
  },
  {
    emoji: "🇫🇷",
    name: "France"
  },
  {
    emoji: "🇬🇧",
    name: "United Kingdom"
  },
  {
    emoji: "🇬🇪",
    name: "Georgia"
  },
  {
    emoji: "🇬🇬",
    name: "Guernsey"
  },
  {
    emoji: "🇬🇭",
    name: "Ghana"
  },
  {
    emoji: "🇬🇮",
    name: "Gibraltar"
  },
  {
    emoji: "🇬🇱",
    name: "Greenland"
  },
  {
    emoji: "🇬🇷",
    name: "Greece"
  },
  {
    emoji: "🇭🇰",
    name: "Hong Kong"
  },
  {
    emoji: "🇭🇳",
    name: "Honduras"
  },
  {
    emoji: "🇭🇷",
    name: "Croatia"
  },
  {
    emoji: "🇭🇹",
    name: "Haiti"
  },
  {
    emoji: "🇭🇺",
    name: "Hungary"
  },
  {
    emoji: "🇮🇩",
    name: "Indonesia"
  },
  {
    emoji: "🇮🇪",
    name: "Ireland"
  },
  {
    emoji: "🇮🇱",
    name: "Israel"
  },
  {
    emoji: "🇮🇲",
    name: "Isle of Man"
  },
  {
    emoji: "🇮🇳",
    name: "India"
  },
  {
    emoji: "🇮🇶",
    name: "Iraq"
  },
  {
    emoji: "🇮🇷",
    name: "Iran"
  },
  {
    emoji: "🇮🇸",
    name: "Iceland"
  },
  {
    emoji: "🇮🇹",
    name: "Italy"
  },
  {
    emoji: "🇯🇪",
    name: "Jersey"
  },
  {
    emoji: "🇯🇲",
    name: "Jamaica"
  },
  {
    emoji: "🇯🇴",
    name: "Jordan"
  },
  {
    emoji: "🇯🇵",
    name: "Japan"
  },
  {
    emoji: "🇰🇪",
    name: "Kenya"
  },
  {
    emoji: "🇰🇬",
    name: "Kyrgyzstan"
  },
  {
    emoji: "🇰🇭",
    name: "Cambodia"
  },
  {
    emoji: "🇰🇵",
    name: "North Korea"
  },
  {
    emoji: "🇰🇷",
    name: "South Korea"
  },
  {
    emoji: "🇰🇿",
    name: "Kazakhstan"
  },
  {
    emoji: "🇱🇨",
    name: "Saint Lucia"
  },
  {
    emoji: "🇱🇮",
    name: "Liechtenstein"
  },
  {
    emoji: "🇱🇰",
    name: "Sri Lanka"
  },
  {
    emoji: "🇱🇷",
    name: "Liberia"
  },
  {
    emoji: "🇱🇹",
    name: "Lithuania"
  },
  {
    emoji: "🇱🇺",
    name: "Luxembourg"
  },
  {
    emoji: "🇱🇻",
    name: "Latvia"
  },
  {
    emoji: "🇱🇾",
    name: "Libya"
  },
  {
    emoji: "🇲🇦",
    name: "Morocco"
  },
  {
    emoji: "🇲🇨",
    name: "Monaco"
  },
  {
    emoji: "🇲🇩",
    name: "Moldova"
  },
  {
    emoji: "🇲🇪",
    name: "Montenegro"
  },
  {
    emoji: "🇲🇬",
    name: "Madagascar"
  },
  {
    emoji: "🇲🇰",
    name: "Macedonia"
  },
  {
    emoji: "🇲🇱",
    name: "Mali"
  },
  {
    emoji: "🇲🇳",
    name: "Mongolia"
  },
  {
    emoji: "🇲🇶",
    name: "Martinique"
  },
  {
    emoji: "🇲🇹",
    name: "Malta"
  },
  {
    emoji: "🇲🇻",
    name: "Maldives"
  },
  {
    emoji: "🇲🇽",
    name: "Mexico"
  },
  {
    emoji: "🇲🇾",
    name: "Malaysia"
  },
  {
    emoji: "🇳🇦",
    name: "Namibia"
  },
  {
    emoji: "🇳🇬",
    name: "Nigeria"
  },
  {
    emoji: "🇳🇱",
    name: "Netherlands"
  },
  {
    emoji: "🇳🇴",
    name: "Norway"
  },
  {
    emoji: "🇳🇵",
    name: "Nepal"
  },
  {
    emoji: "🇳🇿",
    name: "New Zealand"
  },
  {
    emoji: "🇵🇦",
    name: "Panama"
  },
  {
    emoji: "🇵🇪",
    name: "Peru"
  },
  {
    emoji: "🇵🇭",
    name: "Philippines"
  },
  {
    emoji: "🇵🇰",
    name: "Pakistan"
  },
  {
    emoji: "🇵🇱",
    name: "Poland"
  },
  {
    emoji: "🇵🇷",
    name: "Puerto Rico"
  },
  {
    emoji: "🇵🇹",
    name: "Portugal"
  },
  {
    emoji: "🇶🇦",
    name: "Qatar"
  },
  {
    emoji: "🇷🇴",
    name: "Romania"
  },
  {
    emoji: "🇷🇸",
    name: "Serbia"
  },
  {
    emoji: "🇷🇺",
    name: "Russia"
  },
  {
    emoji: "🇸🇦",
    name: "Saudi Arabia"
  },
  {
    emoji: "🇸🇩",
    name: "Sudan"
  },
  {
    emoji: "🇸🇪",
    name: "Sweden"
  },
  {
    emoji: "🇸🇬",
    name: "Singapore"
  },
  {
    emoji: "🇸🇮",
    name: "Slovenia"
  },
  {
    emoji: "🇸🇰",
    name: "Slovakia"
  },
  {
    emoji: "🇸🇳",
    name: "Senegal"
  },
  {
    emoji: "🇸🇴",
    name: "Somalia"
  },
  {
    emoji: "🇹🇭",
    name: "Thailand"
  },
  {
    emoji: "🇹🇳",
    name: "Tunisia"
  },
  {
    emoji: "🇹🇴",
    name: "Tonga"
  },
  {
    emoji: "🇹🇷",
    name: "Turkey"
  },
  {
    emoji: "🇹🇹",
    name: "Trinidad and Tobago"
  },
  {
    emoji: "🇹🇼",
    name: "Taiwan"
  },
  {
    emoji: "🇹🇿",
    name: "Tanzania"
  },
  {
    emoji: "🇺🇦",
    name: "Ukraine"
  },
  {
    emoji: "🇺🇬",
    name: "Uganda"
  },
  {
    emoji: "🇺🇸",
    name: "United States"
  },
  {
    emoji: "🇺🇾",
    name: "Uruguay"
  },
  {
    emoji: "🇺🇿",
    name: "Uzbekistan"
  },
  {
    emoji: "🇻🇦",
    name: "Vatican City"
  },
  {
    emoji: "🇻🇪",
    name: "Venezuela"
  },
  {
    emoji: "🇾🇪",
    name: "Yemen"
  },
  {
    emoji: "🇿🇦",
    name: "South Africa"
  },
  {
    emoji: "🇿🇼",
    name: "Zimbabwe"
  }
];
