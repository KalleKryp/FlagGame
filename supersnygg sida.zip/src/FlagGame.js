import React from 'react'
import './App.css'
import './questions'

function App() {
  const name = 'Gissa flaggan'
  const today = new Date().toLocaleDateString()

  return (
    <div className='App'>

      <header className='App-header'>
        <h1>
          {name}
        </h1>
      </header>


      <p><img src="https://images.emojiterra.com/google/android-11/128px/1f1f8-1f1ea.png" /></p>

      <Flag title="Sverige" >Rätt!</Flag>
      <Flag title="Norge" >Fel!</Flag>
      <Flag title="Finland" >Fel!</Flag>

      <hr></hr>
      <p><img src="https://images.emojiterra.com/google/android-11/512px/1f1ff-1f1fc.png"></img></p>

      <Flag title="Kenya" >Fel!</Flag>
      <Flag title="Syrien" >Fel!</Flag>
      <Flag title="Zimbabwe" >Rätt!</Flag>

      <hr></hr>
      <p><img src="https://images.emojiterra.com/google/android-11/128px/1f1e8-1f1ee.png"></img></p>

      <Flag title="Elfenbenskusten" >Rätt!</Flag>
      <Flag title="Italien" >Fel!</Flag>
      <Flag title="Irland" >Fel!</Flag>


      <hr></hr>
      <p><img src="https://images.emojiterra.com/google/android-11/512px/1f1f0-1f1ee.png"></img></p>

      <Flag title="Paraguay" >Fel!</Flag>
      <Flag title="Kiribati" >Rätt!</Flag>
      <Flag title="Tyskland" >Fel!</Flag>


    </div>
  )
}

function Question(props) {


  return (
    <div>
      <hr></hr>
      <p><img src="https://images.emojiterra.com/google/android-11/512px/1f1f0-1f1ee.png"></img></p>
      <Flag title="Paraguay" >Fel!</Flag>
      <Flag title="Kiribati" >Rätt!</Flag>
      <Flag title="Tyskland" >Fel!</Flag>
    </div>
  )

}

function Flag(props) {
  const [showContent, setShowContent] = React.useState(false);

  let childrenElement = null;
  if (showContent) {
    childrenElement = <div className='ArticleChildren'>{props.children}</div>;
  }

  return (
    <div className='Flag'>
      <h2 onClick={() => setShowContent(!showContent)}>{props.title}</h2>
      <em>{props.date}</em>
      {childrenElement}
    </div>)

}



export default App
