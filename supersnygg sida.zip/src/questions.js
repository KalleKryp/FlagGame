export default [
  {
    questionFlagUrl: 'https://images.emojiterra.com/google/android-11/512px/1f1f0-1f1ee.png',
    alternatives: [
      {
        name: 'Paraguay',
        name: 'Kiribati',
        name: 'Tyskland',
      }
    ],
    correctAnswer: 'Kiribati'
  },
  
];


// <p><img src="https://images.emojiterra.com/google/android-11/512px/1f1f0-1f1ee.png"></img></p>
// <Flag title="Paraguay" >Fel!</Flag>
// <Flag title="Kiribati" >Rätt!</Flag>
// <Flag title="Tyskland" >Fel!</Flag>